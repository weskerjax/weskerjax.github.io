<?php
/**
 * Input object to Query method
 */
class Query {
	/** @var string */
    public $queryXml;
}
