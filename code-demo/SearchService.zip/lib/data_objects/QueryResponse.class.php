<?php
/**
 * Return object to Query method
 */
class QueryResponse {
	/** @var string */
    public $QueryResult;
}