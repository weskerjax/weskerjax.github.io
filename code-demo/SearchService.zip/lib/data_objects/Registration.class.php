<?php
/**
 * Input object to Registration method
 */
class Registration {
	/** @var string */
    public $registrationXml;
}
