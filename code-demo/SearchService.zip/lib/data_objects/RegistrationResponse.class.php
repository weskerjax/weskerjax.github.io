<?php
/**
 * Return object to Registration method
 */
class RegistrationResponse {
	/** @var string */
    public $RegistrationResult;
}
