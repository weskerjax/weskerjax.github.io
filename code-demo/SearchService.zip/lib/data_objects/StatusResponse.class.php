<?php
/**
 * Return object to Status method
 */
class StatusResponse {
	/** @var string */
    public $StatusResult;
}
