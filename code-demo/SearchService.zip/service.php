<?php
require_once "common.php";

if( isset($_GET['class']) && (in_array($_GET['class'],$WSClasses) || in_array($_GET['class'],$WSStructures)) ) {
	$classname = $_GET['class']; 
}else{
	$classname = reset($WSClasses); 
}

$WSHelper = new WSHelper('urn:Microsoft.Search', $classname);
$WSHelper->actor = 'http://'.$_SERVER['HTTP_HOST'];
$WSHelper->use = SOAP_ENCODED; 
$WSHelper->classNameArr = $WSClasses;
$WSHelper->structureMap = $WSStructures;
$WSHelper->setPersistence(SOAP_PERSISTENCE_REQUEST);
$WSHelper->setWSDLCacheFolder('./wsdl/');

try {
	$WSHelper->handle();
}catch(Exception $e) {
	$WSHelper->fault("SERVER", $e->getMessage(),"", $e->__toString());
}
