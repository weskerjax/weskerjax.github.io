/**

element [延伸屬性]{所有元素共用}
    removeDelay="sec"  {設定幾秒鐘後自動[移除]此元素}
    pulsate="sec"  {設定幾秒鐘後自動結束元素[閃爍]}
    
    
input,textarea [延伸屬性]
    emptyText="為空預設提示" {設定當輸入匡為空時的文字提示} 


form 中的[延伸屬性]及[延伸樣式]
    tr
        class="NotNull" {檢查區塊內的元素是否有選項值}
        
    input   
        format="" {表單送出前的格式檢查,但不會檢查為空}    
        	'tel':電話
        	'mobile':行動電話
        	'email':電子信箱
        	'url':網路連結
        
        jtype="" {資料輸入時的輔助}
          (基本格式輸入)
            'uint':無符號整數
            'int':整數
            'float':浮點數
            'id':帳號格式
            'alnum':保留字母和数字及底線

          (輔助日期輸入)
            'date':選擇日期
            'start_date':選擇起始日期
            'end_date':選擇結束日期
                
          (輔助時間輸入)
            'time':選擇時間
            'start_time':選擇起始時間
            'end_time':選擇結束時間
        
*/

/*設定日曆選擇的預設語言*/    
$.datepicker.setDefaults($.datepicker.regional['zh-TW']);

jQuery(function($) {
    /*元素延遲移除*/            
    $('[removeDelay]').each(function(){
        var $el=$(this);    
        var delayTime=parseInt($el.attr('removeDelay'));
        if(delayTime){
            delayTime*=1000;
            setTimeout(function(){
                $el.remove();
            },delayTime);
        }
    });
    $('[pulsate]').each(function(){
        var $el=$(this);    
		$el.show('pulsate',{times:parseInt($el.attr('pulsate'))},600);
    });
 
    /*為空預設文字*/            
    $('[emptyText]').each(function(){
        var $el=$(this);    
        if($.trim($el.val())){return;}

        $el.val($el.attr('emptyText')).css("color","#999").one("focus", function(){
            $el.val('').css("color","");
        }); 
        
    });

        
/**=(表單送出前格式檢查)===============================================*/
    $("form").submit(function(){
        var isPass = true;

        /**=(為空檢查)===============================================*/
        $('.NotNull',this).each(function(){
            var $el=$(this);    
            var isError = false;
            
            var value =  $('input,textarea,select',this).filter(function(){
    			return this.name && !this.disabled && 
    				(this.checked || /select|textarea/i.test(this.nodeName) ||
    					/text|hidden|password|search/i.test(this.type));
    		});
            
            /*處理格式錯誤的顯示*/
            if(value[0]===undefined || value[0].value==''){
                $el.addClass('Error');
                
                if(isPass && value[0]!==undefined){
                    $(value[0]).focus();
                }
                isPass = false;            
            }
        });

        
        /**=(輸入格式檢查)===============================================*/
        $('[format],[jtype]',this).each(function(){
            var $el=$(this);
            var isError = false;
            
            /*資料為空不檢查格式*/
            if($el.val()==''){return;}
            
            /*依分類檢查下列格式*/
            switch($el.attr('format')){
                case 'tel':/*電話*/
                    var value = $el.val();
                    
                    var match = value.match(/[0-9]{2,}-[0-9]{7,}/);
                    isError = (match===null || match[0]!=value); break;
                    
                case 'mobile':/*行動電話*/
                    var value = $el.val();
                    
                    var match = value.match(/09[0-9]{8,}/);
                    isError = (match===null || match[0]!=value); break;
                    
                case 'email':/*電子信箱*/
                    var value = $el.val();
                    
                    var match = value.match(/([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})/);
                    isError = (match===null || match[0]!=value); break;
                                        
                case 'url':/*網路連結*/
                    var value = $el.val();
                    var match = value.match(/[a-zA-Z]+:\/\/[a-zA-Z0-9]+.*$/);
                    
                    isError = (match===null || match[0]!=value); break;
            }
                                        
            switch($el.attr('jtype')){
                case 'date': case 'start_date': case 'end_date':/*日期*/
                    var value = $el.val().replace(/-0*/g,'/');
                    var acc = new Date(value);
                    var match = acc.getFullYear()+"/"+ (acc.getMonth()+1) +"/"+ acc.getDate();
                    
                    isError = (value!=match); break;                    
               
                case 'time': case 'start_time': case 'end_time':/*時間*/
                    var value = $el.val().split(':');
                    var acc = new Date();
                    acc.setHours(value[0],value[1]);
                    value = (isNaN(parseInt(value[0]))?0:parseInt(value[0]));
                    value += ":";
                    value += (isNaN(parseInt(value[1]))?0:parseInt(value[1]));
                    var match = acc.getHours()+":"+acc.getMinutes();
                    
                    isError = (value!=match); break;
            }

            /*錯誤旗標*/
            var flag = $el.parents('tr')[0]; 
            if(!flag){flag = this;}
            flag = $(flag).removeClass('Error');

            /*處理格式錯誤的顯示*/
            if(isError){
                flag.addClass('Error');
                if(isPass){
                    $el.focus();
                    isPass = false;            
                }
            }
                        
        });
        
        return isPass;
    });     
    
    
/**=(輸入的格式類型)===============================================*/
    $("form [jtype]").each(function(){
        var $el=$(this);
        switch($el.attr('jtype')){
        /**=(限制輸入)===============================================*/
            case 'uint':/*無符號整數*/
                $el.keyup(function(){
                	match = this.value.match(/(0|[1-9][0-9]*)/);
                	this.value = match? match[0] : '';
                }) ;
                break;
            case 'int':/*整數*/
                $el.keyup(function(){
                	match = this.value.match(/0|(-?([1-9][0-9]*)?)/);
                	this.value = match? match[0] : '';
                }) ;
                break;
            case 'float':/*浮點數*/
                $el.keyup(function(){
                	match = this.value.match(/(-?(0|[1-9][0-9]*)?)(\.[0-9]*)?/);
                	this.value = match? match[0] : '';
                });
                break;
            case 'id':/*帳號格式*/
                $el.keyup(function(){
                	match = this.value.match(/[a-z][a-z0-9_\.]*/);
                	this.value = match? match[0] : '';
                });
                break;
            case 'alnum':/*保留字母和数字及底線*/
                $el.keyup(function(){
                	match = this.value.match(/[a-z0-9_]*/i);
                	this.value = match? match[0] : '';
                });
                break;


        /**=(輔助日期輸入)===============================================*/
            case 'date':/*選擇日期*/
                $el.css("width","6em")
                .attr("autocomplete","off")
                .val(this.value || ($.datepicker.formatDate('yy-mm-dd', new Date())))
                .datepicker({dateFormat:'yy-mm-dd'});
                break;
                
            case 'start_date':/*選擇起始日期*/
                $el.css("width","6em")
                .attr("autocomplete","off")
                .val(this.value || ($.datepicker.formatDate('yy-mm-dd', new Date())))
                .datepicker({dateFormat:'yy-mm-dd',
                    onSelect: function(dateText){
        				var date = $.datepicker.parseDate('yy-mm-dd', dateText);
        				$("form [jtype='end_date']").datepicker('option',{minDate:date});
                    }
                });
                break;
                
            case 'end_date':/*選擇結束日期*/
                $el.css("width","6em")
                .attr("autocomplete","off")
                .val(this.value || ($.datepicker.formatDate('yy-mm-dd', new Date())))
                .datepicker({
                    dateFormat:'yy-mm-dd',
                    onSelect: function(dateText){
        				var date = $.datepicker.parseDate('yy-mm-dd', dateText);
        				$("form [jtype='start_date']").datepicker('option',{maxDate:date});
                    }
                });
                break;
                
                
        /**=(輔助時間輸入)===============================================*/
            case 'time':/*選擇時間*/
                $el.css("width","4em")
                .attr("autocomplete","off")
                .val(this.value || '00:00')
                .timePicker({step: 15});
                $('div.time-picker').css('margin-top',this.offsetHeight+'px');
                break;
                
            case 'start_time':/*選擇起始時間*/
                $el.css("width","4em")
                .attr("autocomplete","off")
                .val(this.value || '00:00')
                .timePicker({step: 15})
                .change(function() {
                    if ($.timePicker("form [jtype='end_time']").getTime() < $.timePicker(this).getTime()) {
                        $("form [jtype='end_time']").val(this.value);
                    }
                });
                $('div.time-picker').css('margin-top',this.offsetHeight+'px');
                break;
                
            case 'end_time':/*選擇結束時間*/
                $el.css("width","4em")
                .attr("autocomplete","off")
                .val(this.value || '00:00')
                .timePicker({step: 15})
                .change(function() {
                    if ($.timePicker("form [jtype='start_time']").getTime() > $.timePicker(this).getTime()) {
                        $("form [jtype='start_time']").val(this.value);
                    }
                });
                $('div.time-picker').css('margin-top',this.offsetHeight+'px');
                break;
                
        }
        
    }); 
    
}); 
