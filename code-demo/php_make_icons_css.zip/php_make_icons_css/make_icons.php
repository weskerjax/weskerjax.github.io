<?php

/*把目錄改變到當前文件下*/
chdir(dirname(__FILE__));

/*Sprite 圖與圖的間距*/
$spriteGap = 30;

$iconNaming = '.Icon.{name}';
 
/*基本 CSS 定義*/
$iconBaseStyle = <<< EOTPL
.Icon {
    display: -moz-inline-box;
    display: inline-block;
    width: 16px;
    height: 16px;
	text-align: left;
    vertical-align: middle;
    text-indent: -99999px;
    text-decoration: none;
	overflow: hidden;
	border: none;
	background: transparent none 0 0 no-repeat;

    *text-indent: 0;
	*font-size: 0;
	*line-height: 0;
}
.Icon.Move { cursor:move !important; }		
.Icon.Action { cursor:pointer !important; }				
.Icon.Gray {
    filter: url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\'><filter id=\'grayscale\'><feColorMatrix type=\'matrix\' values=\'0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0\'/></filter></svg>#grayscale"); /* Firefox 10+, Firefox on Android */
    filter: grayscale(100%);
    -moz-filter: grayscale(100%);
    -ms-filter: grayscale(100%);
    -o-filter: grayscale(100%);
    filter: gray; /* IE6-9 */
    -webkit-filter: grayscale(100%); /* Chrome 19+, Safari 6+, Safari 6+ iOS */	
}				
.Icon.Translucent {
	filter: alpha(opacity=20);
	-khtml-opacity: 0.2;	
	-moz-opacity: 0.2;
    opacity: 0.2;
	zoom: 1;
}

EOTPL;








/*=[ 取得圖檔資訊 ]====================================================================*/
$maxWidth = 0;
$maxHeight = 0;
$nextTop = 0;
$imageList = array();
foreach (glob('icons/*.{png,jpg,gif}',GLOB_BRACE) as $path){
	$image = new Imagick($path);
	$name = pathinfo($path,PATHINFO_FILENAME);

	if(isset($imageList[$name])){ throw new Exception("圖片名稱重複 [ $name ]"); }
	
	
	$info = array(
		'{top}' => $nextTop, 
		'{image}' => $image,
		'{width}' => $image->getImageWidth(),
		'{height}' => $image->getImageHeight(), 
		'{name}' => $name,
		'{path}' => $path,
		'{isAnimate}' => false
	);
	

	$header = '';
	switch($image->getImageFormat()){
		case "PNG": 
			$header = 'data:image/png;base64,'; break;
		case "JPEG":
			$header = 'data:image/jpeg;base64,'; break;
		case "GIF": 
			$header = 'data:image/gif;base64,'; break;
		default: break;
	}
	
	$info['{uri}'] = $header.base64_encode(file_get_contents($path));	

	$maxWidth = max($maxWidth, $info['{width}']);		
	$maxHeight = max($maxHeight, $info['{height}']);
	
	
	/*檢查圖片是否為動畫*/
	$frameNum = 0;
	foreach($image->deconstructImages() as $i) {
		$frameNum++;
		if ($frameNum > 1) {
			$info['{isAnimate}'] = true;
			break;
		}
	}
	
	if(!$info['{isAnimate}']){
		$nextTop += $info['{height}'] + $spriteGap;
	}


	$imageList[$name] = $info;	
}




/*=[ 製作 CSS Sprite 圖檔 ]====================================================================*/
$spriteImage = new Imagick();
$spriteImage->newImage($maxWidth, $nextTop, new ImagickPixel());
$spriteImage->setImageFormat('png');
$spriteImage->paintTransparentImage(new ImagickPixel(), 0.0, 0);

foreach ($imageList as $name => $info){
	if($info['{isAnimate}']){ continue; } /*忽略 GIF 動畫*/
	
	/*複製 Icon 圖檔到 Sprite */
	$spriteImage->compositeImage(
		$info['{image}'], 
		$info['{image}']->getImageCompose(), 
		0, 
		$info['{top}']
	);		
	
	$info['{image}']->destroy();
	unset($imageList[$name]['{image}']);
}

$spriteImage->writeImage('icons.sprite.png');
$spriteImage->destroy(); 
$spriteImage = null;









/*=[ icons.css ]====================================================================*/
$buffer = array( $iconBaseStyle );
foreach ($imageList as $info){
	$buffer[] = strtr($iconNaming.'{ width: {width}px; height: {height}px; background-image: url({path}); }', $info);
}

file_put_contents('icons.css', join("\n", $buffer));






/*=[ icons.base64.css ]====================================================================*/
$buffer = array( $iconBaseStyle );
foreach ($imageList as $info){
	$buffer[] = strtr($iconNaming.'{ width: {width}px; height: {height}px; background-image: url({uri}); }', $info);
}

file_put_contents('icons.base64.css', join("\n", $buffer));





/*=[ icons.sprite.css ]====================================================================*/
$buffer = array( $iconBaseStyle );
$buffer[] = '.Icon { background: transparent url(icons.sprite.png) 100px 100px no-repeat; }';
foreach ($imageList as $info){
	if($info['{isAnimate}']){ 
		$buffer[] = strtr($iconNaming.'{ width: {width}px; height: {height}px; background: url({path}) 0 0 no-repeat; }', $info);
	}else{
		$buffer[] = strtr($iconNaming.'{ width: {width}px; height: {height}px; background-position: 0 -{top}px; }', $info);
	}

}

file_put_contents('icons.sprite.css', join("\n", $buffer));





/*=[ icons.readme.html ]====================================================================*/
$maxWidth += 10;
$maxHeight += 5;
$htmlContent = <<< EOTPL
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Icons Readme</title>
<link id="include_css" href="icons.base64.css" type="text/css" rel="stylesheet" />
<style type="text/css">
	fieldset {
		float: left;
	}
	#icon_list {
		list-style: none;
	}
	#icon_list li {
		float: left;
		text-align: center;
		width: {$maxWidth}px;		
		height: {$maxHeight}px;
		line-height: {$maxHeight}px;
	}
	#icon_list li.selected {
		background: #9CF;
	}
	#icon_list li i {
		vertical-align: middle;	
	}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery(function($) { 
	var selected = null;
	$('#icon_list').on({
		click: function(){
			$('#icon_list li').removeClass('selected');
			
			if(selected == this){ selected = null; return; }
			
			selected = this;
			$('#icon_code').val($(this).html());	
			$(this).addClass('selected');
		},
		mouseover: function(){
			if(selected){ return; }
			$('#icon_code').val($(this).html());
		},
		mouseout: function(){
			if(selected){ return; }
			$('#icon_code').val('');
		}
	},'li');
	
	$('[name=include]').change(function(){
		$('#include_css').attr('href', $(this).val());
	});


	var cursorGroups = $('[name=cursor]').map(function(){
		return this.value;
	}).toArray().join(' ');

	$('[name=cursor]').change(function(){
		$('#icon_list .Icon').removeClass(cursorGroups);
		if($(this).val()){
			$('#icon_list .Icon').addClass($(this).val());
		}

		if(selected){
			$('#icon_code').val($(selected).html());
		}
	});


	var filterGroups = $('[name=filter]').map(function(){
		return this.value;
	}).toArray().join(' ');

	$('[name=filter]').change(function(){
		$('#icon_list .Icon').removeClass(filterGroups);
		if($(this).val()){
			$('#icon_list .Icon').addClass($(this).val());
		}

		if(selected){
			$('#icon_code').val($(selected).html());
		}
	});
});	
</script>
</head>
<body>
<form autocomplete="off">
  <fieldset>
	<legend>include css</legend>
	<label><input type="radio" name="include" value="icons.css" />icons.css</label>	
	<label><input type="radio" name="include" value="icons.base64.css" checked="checked" />icons.base64.css</label>	
	<label><input type="radio" name="include" value="icons.sprite.css" />icons.sprite.css</label>	
  </fieldset>
  <fieldset>
	<legend>cursor</legend>
	<label><input type="radio" name="cursor" value="" checked="checked" />normal</label>	
	<label><input type="radio" name="cursor" value="Action" />Action</label>	
	<label><input type="radio" name="cursor" value="Move" />Move</label>	
  </fieldset>
  <fieldset>
	<legend>filter</legend>
	<label><input type="radio" name="filter" value="" checked="checked" />none</label>	
	<label><input type="radio" name="filter" value="Gray" />Gray</label>	
	<label><input type="radio" name="filter" value="Translucent" />Translucent</label>	
  </fieldset>
  
  <div style="clear:both; padding:10px;">
   <input id="icon_code" style="width:400px;" onfocus="select();" />
  </div>
</form>

<ul id="icon_list" >
<li><i class="Icon Wait"></i></li>

EOTPL;

$buffer = array($htmlContent);
foreach ($imageList as $info){
	$buffer[] = strtr('<li><i class="'.trim(str_replace('.',' ',$iconNaming)).'"></i></li>', $info);
}
$buffer[] = '</ul></body></html>';

file_put_contents('icons.readme.html', join("\n", $buffer));








/*=[ Run Complete ]====================================================================*/
echo " [ Run Complete ] ";


