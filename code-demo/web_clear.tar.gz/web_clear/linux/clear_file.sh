#!/bin/bash

PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

./web_clear -v /home/test/index.php

#./web_clear -v `find /home/test -name '*.css' -or -name '*.js'`


exit 0
